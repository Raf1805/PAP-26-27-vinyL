<?php
header('Content-Type: application/json');
include("conexao.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $pass = $_POST['pass'] ?? '';

    $check = $conn->prepare("SELECT id FROM utilizadores WHERE username = ? OR email = ?");
    $check->bind_param("ss", $username, $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        echo json_encode(["sucesso" => false, "mensagem" => "Username ou email já existe."]);
        exit;
    }
    $check->close();

    $stmt = $conn->prepare("INSERT INTO utilizadores (username, email, pass) VALUES (?, ?, SHA2(?, 256))");
    $stmt->bind_param("sss", $username, $email, $pass);

    if ($stmt->execute()) {
        echo json_encode(["sucesso" => true, "mensagem" => "Conta criada com sucesso!"]);
    } else {
        echo json_encode(["sucesso" => false, "mensagem" => "Erro ao criar conta."]);
    }

    $stmt->close();
    $conn->close();
}
?>
