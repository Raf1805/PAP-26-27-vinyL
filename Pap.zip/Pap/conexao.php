<?php
$host = "127.0.0.1";
$user = "root";
$pass = "";
$dbname = "vinyl";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Erro na ligação: " . $conn->connect_error);
}
?>
