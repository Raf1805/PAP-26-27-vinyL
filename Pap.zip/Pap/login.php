<?php
session_start();
header('Content-Type: application/json');
include("conexao.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $login = trim($_POST['login'] ?? '');
    $pass = $_POST['pass'] ?? '';

    $stmt = $conn->prepare("SELECT id, username FROM utilizadores WHERE (username = ? OR email = ?) AND pass = SHA2(?, 256)");
    $stmt->bind_param("sss", $login, $login, $pass);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        $user = $resultado->fetch_assoc();
        $_SESSION['id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        echo json_encode([
            "sucesso" => true,
            "username" => $user['username']
        ]);
    } else {
        echo json_encode([
            "sucesso" => false,
            "mensagem" => "Username ou palavra-passe incorretos."
        ]);
    }

    $stmt->close();
    $conn->close();
}
?>
