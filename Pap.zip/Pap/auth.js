var loginForm = document.getElementById("loginForm");
var registerForm = document.getElementById("registerForm");

// --- LOGIN ---
loginForm.addEventListener("submit", async function(event) {
    event.preventDefault();
    var username = document.getElementById("loginUsername").value;
    var password = document.getElementById("loginPassword").value;
    var message = document.getElementById("loginMessage");

    var formData = new FormData();
    formData.append("login", username);
    formData.append("pass", password);

    try {
        var resposta = await fetch("login.php", {
            method: "POST",
            body: formData
        });
        var dados = await resposta.json();

        if (dados.sucesso) {
            // Mantém compatibilidade com o teu index.html
            sessionStorage.setItem("vinyLCurrentUser", dados.username);
            window.location.href = "index.html";
        } else {
            message.style.color = "#ff7070";
            message.textContent = dados.mensagem;
        }
    } catch (erro) {
        message.style.color = "#ff7070";
        message.textContent = "Erro ao ligar ao servidor.";
    }
});

// --- REGISTO ---
registerForm.addEventListener("submit", async function(event) {
    event.preventDefault();
    var username = document.getElementById("registerUsername").value;
    var email = document.getElementById("registerEmail").value;
    var password = document.getElementById("registerPassword").value;
    var confirmPassword = document.getElementById("confirmPassword").value;
    var message = document.getElementById("registerMessage");

    if (password != confirmPassword) {
        message.style.color = "#ff7070";
        message.textContent = "Palavra-passe não coincide.";
        return;
    }

    var formData = new FormData();
    formData.append("username", username);
    formData.append("email", email);
    formData.append("pass", password);

    try {
        var resposta = await fetch("registo.php", {
            method: "POST",
            body: formData
        });
        var dados = await resposta.json();

        if (!dados.sucesso) {
            message.style.color = "#ff7070";
            message.textContent = dados.mensagem;
            return;
        }

        // Faz exatamente o mesmo que o teu código original fazia ao criar conta
        document.getElementById("loginUsername").value = username;
        document.getElementById("loginPassword").value = "";
        registerForm.reset();
        message.textContent = "";
        document.getElementById("loginChoice").checked = true;

        var loginMessage = document.getElementById("loginMessage");
        loginMessage.style.color = "#4ade80";
        loginMessage.textContent = dados.mensagem;
    } catch (erro) {
        message.style.color = "#ff7070";
        message.textContent = "Erro ao ligar ao servidor.";
    }
});
